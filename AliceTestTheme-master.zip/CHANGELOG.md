## 1.3 / Sat Feb 15 2014

> functions.php 感染木马，目前已删除，感谢@landu 提醒

* 优化精简了style.css
* 调整theme-update.php文件的位置

## 1.2 / Wed Jan 15 2014

> 新增主题检查更新功能

## 1.1.1 / Tues Jan 14 2014

* 设置顶栏轮播margin-top
* 导航栏字体大小调整
* 多说评论框文章页面评论条数字体大小
* 调整“最新图文”图片显示方式，适应长图片
* 替换“<?= ”为“<?php echo ”，兼容php 5.4- 主机环境

## 1.1 / Fri Dec 20 2013

> 支持wordpress 3.8 正式版

* 兼容IE 7+ 、双核浏览器兼容模式
* 优化静态资源，提升页面加载速度