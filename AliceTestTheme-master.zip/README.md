Alice sample test theme - A Business theme for WordPress
=======

## Theme 

这个一个灰色大气的的WordPress主题

当你开发一款作品（产品）的时候，用心去塑造它，给予它灵魂，那么它便是“活”的。



## Feature

*  无限级的导航菜单
*  大气美观的Banner-Slide图片轮播组件
*  “核心服务”组件
*  可切换的“最新图文”、“热评文章”组件
*  图片型友情链接与FOOTER组件
*  无限级的评论列表展示框
*  异步提交的、刷新前可更新的评论提交框
*  全新改造和新增的14个小工具，全面兼容DChaser

## Usage

*  将ZIP 主题包解压到网站 ``\wordpress\wp-content\themes\`` 目录下或直接后台上传ZIP主题包
*  进入 ``仪表盘->外观->主题`` 启用
*  进入 ``仪表盘->外观->DChaser主题设置`` 设置

## Support

*  E-Mail: aliceding@miapple.ca
*  Cell: 647-898-6497

## Donate

https://cn.aliceding.com/   右边栏



